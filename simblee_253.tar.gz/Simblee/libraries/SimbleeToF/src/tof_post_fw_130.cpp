/*!*****************************************************************************
* @file   tof_post_fw_130.c
*
*   Copyright (c) 2015-2017 Heptagon
*
* @brief  Main high-level ToF functions for POST Firmware 1.3.0
*******************************************************************************/

#include "i2c_tof.h"

/******************** END of tof_post_fw_130.c *****************/